import json
import os

TASKS_FILE = "tasks.json"

def load_tasks():
    if not os.path.exists(TASKS_FILE):
        return []
    with open(TASKS_FILE, "r") as f:
        return json.load(f)

def save_tasks(tasks):
    with open(TASKS_FILE, "w") as f:
        json.dump(tasks, f, indent=4)

def list_tasks(tasks):
    if not tasks:
        print("No tasks found.")
        return
    for i, task in enumerate(tasks, 1):
        status = "✅" if task["done"] else "❌"
        print(f"{i}. {task['task']} [{status}]")

def add_task(tasks, task_desc):
    tasks.append({"task": task_desc, "done": False})
    save_tasks(tasks)
    print("Task added.")

def complete_task(tasks, index):
    try:
        tasks[index]["done"] = True
        save_tasks(tasks)
        print("Task marked as completed.")
    except IndexError:
        print("Invalid task number.")

def delete_task(tasks, index):
    try:
        tasks.pop(index)
        save_tasks(tasks)
        print("Task deleted.")
    except IndexError:
        print("Invalid task number.")

def main():
    tasks = load_tasks()
    while True:
        print("\n1. List Tasks\n2. Add Task\n3. Complete Task\n4. Delete Task\n5. Exit")
        choice = input("Choose an option: ")

        if choice == "1":
            list_tasks(tasks)
        elif choice == "2":
            task_desc = input("Enter task: ")
            add_task(tasks, task_desc)
        elif choice == "3":
            list_tasks(tasks)
            idx = int(input("Enter task number to complete: ")) - 1
            complete_task(tasks, idx)
        elif choice == "4":
            list_tasks(tasks)
            idx = int(input("Enter task number to delete: ")) - 1
            delete_task(tasks, idx)
        elif choice == "5":
            break
        else:
            print("Invalid option. Try again.")

if __name__ == "__main__":
    main()
 
